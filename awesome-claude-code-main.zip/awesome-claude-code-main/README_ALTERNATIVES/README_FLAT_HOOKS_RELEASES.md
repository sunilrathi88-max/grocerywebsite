<!-- GENERATED FILE: do not edit directly -->
<!--lint disable remark-lint:awesome-badge-->

<h3 align="center">Pick Your Style:</h3>
<p align="center">
<a href="../"><img src="../assets/badge-style-awesome.svg" alt="Awesome" height="28"></a>
<a href="README_EXTRA.md"><img src="../assets/badge-style-extra.svg" alt="Extra" height="28"></a>
<a href="README_CLASSIC.md"><img src="../assets/badge-style-classic.svg" alt="Classic" height="28"></a>
<a href="README_FLAT_ALL_AZ.md"><img src="../assets/badge-style-flat.svg" alt="Flat" height="28" style="border: 2px solid #71717a; border-radius: 4px;"></a>
</p>

# Awesome Claude Code (Flat)

[![Awesome](https://awesome.re/badge-flat2.svg)](https://awesome.re)

A flat list view of all resources. Category: **Hooks** | Sorted: by latest release (30 days)

---

## Sort By:

<p align="center">
  <a href="README_FLAT_HOOKS_AZ.md"><img src="../assets/badge-sort-az.svg" alt="A - Z" height="48"></a>
  <a href="README_FLAT_HOOKS_UPDATED.md"><img src="../assets/badge-sort-updated.svg" alt="UPDATED" height="48"></a>
  <a href="README_FLAT_HOOKS_CREATED.md"><img src="../assets/badge-sort-created.svg" alt="CREATED" height="48"></a>
  <a href="README_FLAT_HOOKS_RELEASES.md"><img src="../assets/badge-sort-releases.svg" alt="RELEASES" height="48" style="border: 3px solid #f59e0b; border-radius: 6px;"></a>
</p>
<p align="center"><strong>Category:</strong></p>
<p align="center">
  <a href="README_FLAT_ALL_RELEASES.md"><img src="../assets/badge-cat-all.svg" alt="All" height="28"></a>
  <a href="README_FLAT_TOOLING_RELEASES.md"><img src="../assets/badge-cat-tooling.svg" alt="Tooling" height="28"></a>
  <a href="README_FLAT_COMMANDS_RELEASES.md"><img src="../assets/badge-cat-commands.svg" alt="Commands" height="28"></a>
  <a href="README_FLAT_CLAUDE-MD_RELEASES.md"><img src="../assets/badge-cat-claude-md.svg" alt="CLAUDE.md" height="28"></a>
  <a href="README_FLAT_WORKFLOWS_RELEASES.md"><img src="../assets/badge-cat-workflows.svg" alt="Workflows" height="28"></a>
  <a href="README_FLAT_HOOKS_RELEASES.md"><img src="../assets/badge-cat-hooks.svg" alt="Hooks" height="28" style="border: 2px solid #f97316; border-radius: 4px;"></a>
  <a href="README_FLAT_SKILLS_RELEASES.md"><img src="../assets/badge-cat-skills.svg" alt="Skills" height="28"></a>
  <a href="README_FLAT_STYLES_RELEASES.md"><img src="../assets/badge-cat-styles.svg" alt="Styles" height="28"></a>
  <a href="README_FLAT_STATUSLINE_RELEASES.md"><img src="../assets/badge-cat-statusline.svg" alt="Status" height="28"></a>
  <a href="README_FLAT_DOCS_RELEASES.md"><img src="../assets/badge-cat-docs.svg" alt="Docs" height="28"></a>
  <a href="README_FLAT_CLIENTS_RELEASES.md"><img src="../assets/badge-cat-clients.svg" alt="Clients" height="28"></a>
</p>
<p align="center"><em>Currently viewing: **Hooks** sorted by latest release (30 days) (past 30 days)</em></p>

---

## Resources

> **Note:** Latest release data is pulled from GitHub Releases only. Projects without GitHub Releases will not show release info here. Please verify with the project directly.

<table>
<thead>
<tr>
<th>Resource</th>
<th>Version</th>
<th>Source</th>
<th>Release Date</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://github.com/vaporif/parry"><b>parry</b></a><br>by <a href="https://github.com/vaporif">Dmytro Onypko</a></td>
<td>v0.1.0-alpha.2</td>
<td>GitHub</td>
<td>2026-03-14</td>
<td>Prompt injection scanner for Claude Code hooks. Scans tool inputs and outputs for injection attacks, secrets, and data exfiltration attempts. [NOTE: Early development phase but worth a look.]</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/vaporif/parry?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/vaporif/parry?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/vaporif/parry?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/vaporif/parry?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/vaporif/parry?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/vaporif/parry?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/vaporif/parry?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/vaporif/parry?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/vaporif/parry?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/backnotprop/plannotator"><b>Plannotator</b></a><br>by <a href="https://github.com/backnotprop">backnotprop</a></td>
<td>v0.12.0</td>
<td>GitHub</td>
<td>2026-03-12</td>
<td>Interactive plan review UI that intercepts ExitPlanMode via hooks, letting users visually annotate plans with comments, deletions, and replacements before approving or denying with detailed feedback.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/backnotprop/plannotator?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/backnotprop/plannotator?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/backnotprop/plannotator?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/backnotprop/plannotator?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/backnotprop/plannotator?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/backnotprop/plannotator?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/backnotprop/plannotator?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/backnotprop/plannotator?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/backnotprop/plannotator?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/aannoo/claude-hook-comms"><b>Claude Code Hook Comms (HCOM)</b></a><br>by <a href="https://github.com/aannoo">aannoo</a></td>
<td>v0.7.4</td>
<td>GitHub</td>
<td>2026-03-11</td>
<td>Lightweight CLI tool for real-time communication between Claude Code sub agents using hooks. Enables multi-agent collaboration with @-mention targeting, live dashboard monitoring, and zero-dependency implementation. [NOTE: At the time of posting, this resource is a little unstable - I'm sharing it anyway, because I think it's incredibly promising and creative. I hope by the time you read this, it is production-ready.]</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/aannoo/claude-hook-comms?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/aannoo/claude-hook-comms?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/aannoo/claude-hook-comms?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/aannoo/claude-hook-comms?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/aannoo/claude-hook-comms?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/aannoo/claude-hook-comms?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/aannoo/claude-hook-comms?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/aannoo/claude-hook-comms?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/aannoo/claude-hook-comms?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/ldayton/Dippy"><b>Dippy</b></a><br>by <a href="https://github.com/ldayton">Lily Dayton</a></td>
<td>v0.2.6</td>
<td>GitHub</td>
<td>2026-03-09</td>
<td>Auto-approve safe bash commands using AST-based parsing, while prompting for destructive operations. Solves permission fatigue without disabling safety. Supports Claude Code, Gemini CLI, and Cursor.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/ldayton/Dippy?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/ldayton/Dippy?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/ldayton/Dippy?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/ldayton/Dippy?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/ldayton/Dippy?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/ldayton/Dippy?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/ldayton/Dippy?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/ldayton/Dippy?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/ldayton/Dippy?style=flat-square" alt="license"></td>
</tr>
</tbody>
</table>

---

**Total Resources:** 4

**Last Generated:** 2026-03-28
