<!-- GENERATED FILE: do not edit directly -->
<!--lint disable remark-lint:awesome-badge-->

<h3 align="center">Pick Your Style:</h3>
<p align="center">
<a href="../"><img src="../assets/badge-style-awesome.svg" alt="Awesome" height="28"></a>
<a href="README_EXTRA.md"><img src="../assets/badge-style-extra.svg" alt="Extra" height="28"></a>
<a href="README_CLASSIC.md"><img src="../assets/badge-style-classic.svg" alt="Classic" height="28"></a>
<a href="README_FLAT_ALL_AZ.md"><img src="../assets/badge-style-flat.svg" alt="Flat" height="28" style="border: 2px solid #71717a; border-radius: 4px;"></a>
</p>

# Awesome Claude Code (Flat)

[![Awesome](https://awesome.re/badge-flat2.svg)](https://awesome.re)

A flat list view of all resources. Category: **Clients** | Sorted: by latest release (30 days)

---

## Sort By:

<p align="center">
  <a href="README_FLAT_CLIENTS_AZ.md"><img src="../assets/badge-sort-az.svg" alt="A - Z" height="48"></a>
  <a href="README_FLAT_CLIENTS_UPDATED.md"><img src="../assets/badge-sort-updated.svg" alt="UPDATED" height="48"></a>
  <a href="README_FLAT_CLIENTS_CREATED.md"><img src="../assets/badge-sort-created.svg" alt="CREATED" height="48"></a>
  <a href="README_FLAT_CLIENTS_RELEASES.md"><img src="../assets/badge-sort-releases.svg" alt="RELEASES" height="48" style="border: 3px solid #f59e0b; border-radius: 6px;"></a>
</p>
<p align="center"><strong>Category:</strong></p>
<p align="center">
  <a href="README_FLAT_ALL_RELEASES.md"><img src="../assets/badge-cat-all.svg" alt="All" height="28"></a>
  <a href="README_FLAT_TOOLING_RELEASES.md"><img src="../assets/badge-cat-tooling.svg" alt="Tooling" height="28"></a>
  <a href="README_FLAT_COMMANDS_RELEASES.md"><img src="../assets/badge-cat-commands.svg" alt="Commands" height="28"></a>
  <a href="README_FLAT_CLAUDE-MD_RELEASES.md"><img src="../assets/badge-cat-claude-md.svg" alt="CLAUDE.md" height="28"></a>
  <a href="README_FLAT_WORKFLOWS_RELEASES.md"><img src="../assets/badge-cat-workflows.svg" alt="Workflows" height="28"></a>
  <a href="README_FLAT_HOOKS_RELEASES.md"><img src="../assets/badge-cat-hooks.svg" alt="Hooks" height="28"></a>
  <a href="README_FLAT_SKILLS_RELEASES.md"><img src="../assets/badge-cat-skills.svg" alt="Skills" height="28"></a>
  <a href="README_FLAT_STYLES_RELEASES.md"><img src="../assets/badge-cat-styles.svg" alt="Styles" height="28"></a>
  <a href="README_FLAT_STATUSLINE_RELEASES.md"><img src="../assets/badge-cat-statusline.svg" alt="Status" height="28"></a>
  <a href="README_FLAT_DOCS_RELEASES.md"><img src="../assets/badge-cat-docs.svg" alt="Docs" height="28"></a>
  <a href="README_FLAT_CLIENTS_RELEASES.md"><img src="../assets/badge-cat-clients.svg" alt="Clients" height="28" style="border: 2px solid #f43f5e; border-radius: 4px;"></a>
</p>
<p align="center"><em>Currently viewing: **Clients** sorted by latest release (30 days) (past 30 days)</em></p>

---

## Resources

> **Note:** Latest release data is pulled from GitHub Releases only. Projects without GitHub Releases will not show release info here. Please verify with the project directly.

<table>
<thead>
<tr>
<th>Resource</th>
<th>Version</th>
<th>Source</th>
<th>Release Date</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://github.com/phiat/claude-esp"><b>claude-esp</b></a><br>by <a href="https://github.com/phiat">phiat</a></td>
<td>v0.3.1</td>
<td>GitHub</td>
<td>2026-02-28</td>
<td>Go-based TUI that streams Claude Code's hidden output (thinking, tool calls, subagents) to a separate terminal. Watch multiple sessions simultaneously, filter by content type, and track background tasks. Ideal for debugging or understanding what Claude is doing under the hood without interrupting your main session.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/phiat/claude-esp?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/phiat/claude-esp?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/phiat/claude-esp?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/phiat/claude-esp?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/phiat/claude-esp?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/phiat/claude-esp?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/phiat/claude-esp?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/phiat/claude-esp?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/phiat/claude-esp?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/stravu/crystal"><b>crystal</b></a><br>by <a href="https://github.com/stravu">stravu</a></td>
<td>v0.3.5</td>
<td>GitHub</td>
<td>2026-02-26</td>
<td>A full-fledged desktop application for orchestrating, monitoring, and interacting with Claude Code agents.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/stravu/crystal?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/stravu/crystal?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/stravu/crystal?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/stravu/crystal?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/stravu/crystal?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/stravu/crystal?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/stravu/crystal?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/stravu/crystal?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/stravu/crystal?style=flat-square" alt="license"></td>
</tr>
</tbody>
</table>

---

**Total Resources:** 2

**Last Generated:** 2026-03-28
